package com.huya.niko.homepage.ui.activity;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class NikoHomeActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
