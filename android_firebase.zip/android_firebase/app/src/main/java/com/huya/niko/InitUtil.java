package com.huya.niko;

import android.app.Application;
import android.content.Context;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.huya.niko.common.push.utils.FirebaseInstanceGetter;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class InitUtil {
    private static final String TAG = InitUtil.class.getName();

    public static void init(final Application context) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                predictFirebaseRemoteConfig(context);
            }
        }).start();
    }

    private static void predictFirebaseRemoteConfig(Context context) {
        final Map<String, String> mapRemoteConfig = new HashMap<>();
        mapRemoteConfig.put("Room", "prediction_room");
        mapRemoteConfig.put("Giftsend", "prediction_giftsend");
        mapRemoteConfig.put("Fastsend", "prediction_fastsend");
        mapRemoteConfig.put("Watch", "prediction_watch");
        mapRemoteConfig.put("Follow", "prediction_follow");
        mapRemoteConfig.put("Spend", "prediction_payer");
        mapRemoteConfig.put("Churn", "prediction_churn");

        final FirebaseRemoteConfig firebaseRemoteConfig = FirebaseInstanceGetter.getFirebaseRemoteConfig(context);
        if(firebaseRemoteConfig != null){
            firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
                @Override
                public void onComplete(@NonNull Task<Boolean> task) {
                    if (task.isSuccessful()) {
                        Log.i(TAG, "Firebase Remote Config fetch Successful");
                    } else {
                        Log.i(TAG, "Firebase Remote Config fetch Failed");
                    }

                    for (String key : mapRemoteConfig.keySet()) {
                        if (firebaseRemoteConfig.getBoolean(key)) {
                            String eventId = mapRemoteConfig.get(key);
                            Log.i(TAG, "eventId: " + eventId);
                        }
                    }
                }
            });
        } else {
            Log.i(TAG, "predictFirebaseRemoteConfig firebaseRemoteConfig == null");
        }
    }
}
