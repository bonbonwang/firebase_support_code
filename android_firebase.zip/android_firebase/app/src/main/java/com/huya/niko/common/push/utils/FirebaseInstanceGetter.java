package com.huya.niko.common.push.utils;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import androidx.annotation.Nullable;

/**
 * @author: darren
 * @date: 2020-02-28
 * @description: 用于处理FirebaseInitProvider.onCreate因某种原因未调用，导致FirebaseApp未初始化的问题
 */
public class FirebaseInstanceGetter {

     static final String TAG = "FirebaseInstanceGetter";

    @Nullable
    public static FirebaseRemoteConfig getFirebaseRemoteConfig(Context context) {
        FirebaseRemoteConfig firebaseRemoteConfig = null;
        try{
            firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        } catch (Exception e){
            e.printStackTrace();
        }
        if(firebaseRemoteConfig == null){
            FirebaseApp.initializeApp(context);
            try{
                firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return firebaseRemoteConfig;
    }


}
